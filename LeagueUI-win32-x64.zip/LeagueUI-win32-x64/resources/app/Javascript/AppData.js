/**
 * Created by Matt on 12/12/2016.
 */

function AppData() {
    this.host = "";
    this.port = "";
    this.nickname = "";
    this.leaguePath = "";
}